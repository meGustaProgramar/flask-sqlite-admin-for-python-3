# flask-sqlite-admin-for-Python-3
twaldear's flask-sqlite-admin modified for use with Python 3

https://github.com/twaldear/flask-sqlite-admin
